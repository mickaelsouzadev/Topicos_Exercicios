from setuptools import setup

setup(
    name="sistema_func",
    version="1.0.0.0.0",
    description="Pacote da matéria de TAP",
    author="Mickael Souza",
    author_email="mickael.souza.if@gmail.com",
    url="www.ifsul.edu.br",
    packages=["Core"]
)
